Upgrading from 7.x-1.0-beta2
----------------------------

The Token module [http://drupal.org/project/token] is now required. Please
ensure that it is installed.
